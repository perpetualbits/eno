#!/usr/bin/env python3
"""
tests/test_prototype_a.py — smoke test for SPINE Prototype A.

Verifies the three success criteria from spine_core_v0_2_design.md §8.6:

  1. The rolled-up file expands to the recorded reference output.
  2. The flat-form file expands to the same byte-identical output.
  3. The rolled-up file is smaller in canonical bytes than the flat
     file.

Plus one bonus check:

  4. Reachability drops `orphan_chord` and keeps `cello_main`.

Exits 0 on success, 1 on any failure. No external test framework.
"""

from __future__ import annotations

import io
import os
import re
import sys
from contextlib import redirect_stdout

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "src"))

import expand  # noqa: E402


ROLLED = os.path.join(ROOT, "examples", "phrase_motif.spine")
FLAT = os.path.join(ROOT, "examples", "phrase_motif_flat.spine")
REFERENCE = os.path.join(ROOT, "examples", "phrase_motif.expanded.txt")


def expand_to_string(path: str) -> str:
    with open(path) as f:
        stmts = expand.parse(f.read())
    events = expand.expand(stmts)
    return "\n".join(ev.as_line() for ev in events) + "\n"


def canonical_size(path: str) -> int:
    with open(path) as f:
        text = f.read()
    text = re.sub(r"#[^\n]*", "", text)
    text = re.sub(r"\s+", " ", text).strip()
    return len(text)


def main() -> int:
    failures: list[str] = []

    # 1. Rolled expansion matches reference.
    with open(REFERENCE) as f:
        expected = f.read()
    rolled_out = expand_to_string(ROLLED)
    if rolled_out != expected:
        failures.append(
            "rolled expansion does not match recorded reference\n"
            f"--- expected ---\n{expected}\n--- got ---\n{rolled_out}"
        )

    # 2. Flat expansion matches rolled expansion.
    flat_out = expand_to_string(FLAT)
    if flat_out != rolled_out:
        failures.append(
            "flat expansion differs from rolled expansion\n"
            f"--- rolled ---\n{rolled_out}\n--- flat ---\n{flat_out}"
        )

    # 3. Rolled file is smaller than flat in canonical bytes.
    rolled_size = canonical_size(ROLLED)
    flat_size = canonical_size(FLAT)
    if rolled_size >= flat_size:
        failures.append(
            f"rolled canonical size ({rolled_size}) is not smaller "
            f"than flat ({flat_size}) — structural compression failed"
        )

    # 4. Reachability drops orphan_chord, keeps cello_main.
    with open(ROLLED) as f:
        stmts = expand.parse(f.read())
    table = expand.collect_top_level_ids(stmts)
    reachable = expand.reachable_from(table, "demo_root", top_level=stmts)
    if "orphan_chord" in reachable:
        failures.append("orphan_chord should be unreachable but was reached")
    if "cello_main" not in reachable:
        failures.append(
            "cello_main should be reachable via LNK from motif_asc"
        )

    if failures:
        print(f"FAIL: {len(failures)} check(s) failed\n", file=sys.stderr)
        for f in failures:
            print(f, file=sys.stderr)
            print(file=sys.stderr)
        return 1

    print(f"OK: all 4 checks passed")
    print(f"     events expanded:   {expected.count(chr(10))}")
    print(f"     rolled canonical:  {rolled_size} bytes")
    print(f"     flat canonical:    {flat_size} bytes")
    print(f"     compression:       {flat_size / rolled_size:.2f}x")
    return 0


if __name__ == "__main__":
    sys.exit(main())
