#!/usr/bin/env python3
"""
tests/test_prototype_b.py — smoke test for SPINE Prototype B (patchbay).

Verifies:

  1. The synth_voice patch expands to the recorded reference graph.
  2. MOD on a patch node produces a variant with the override applied
     and the unchanged parameters inherited.
  3. Cross-dialect LNK with matching shapes (event -> event) is
     recorded silently.
  4. Cross-dialect LNK with mismatched shapes (signal -> event) is
     recorded with a warning.
  5. Reachability drops unreached patch nodes (orphan_lfo) and
     unreached MOD variants.
  6. Topological order respects the signal/value graph; cross-dialect
     event inputs don't pin patch-node ordering.
  7. Prototype A's music expansion still works unchanged.

Exits 0 on success, 1 on any failure.
"""

from __future__ import annotations

import io
import os
import re
import sys
from contextlib import redirect_stderr, redirect_stdout

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "src"))

import expand  # noqa: E402


SYNTH = os.path.join(ROOT, "examples", "synth_voice.spine")
GRAPH_REF = os.path.join(ROOT, "examples", "synth_voice.graph.txt")
MUSIC_SRC = os.path.join(ROOT, "examples", "phrase_motif.spine")
MUSIC_REF = os.path.join(ROOT, "examples", "phrase_motif.expanded.txt")


def main() -> int:
    failures: list[str] = []

    # ---------------------------------------------------------------
    # 1. Patch graph matches recorded reference.
    # ---------------------------------------------------------------
    with open(SYNTH) as f:
        stmts = expand.parse(f.read())
    graph = expand.expand_patch(stmts)
    rendered = expand.render_patch_graph(graph)
    with open(GRAPH_REF) as f:
        expected = f.read()
    if rendered != expected:
        failures.append(
            "patch graph does not match recorded reference\n"
            f"--- expected ---\n{expected}\n--- got ---\n{rendered}"
        )

    # ---------------------------------------------------------------
    # 2. MOD on a patch node: override + inheritance.
    # ---------------------------------------------------------------
    filt_bright = next((n for n in graph.nodes if n.id == "filt_bright"), None)
    if filt_bright is None:
        failures.append("filt_bright MOD variant missing from graph")
    else:
        if filt_bright.params.get("cutoff") != 2400.0:
            failures.append(
                f"filt_bright.cutoff should be 2400.0 (overridden), "
                f"got {filt_bright.params.get('cutoff')!r}"
            )
        if filt_bright.params.get("q") != 0.7:
            failures.append(
                f"filt_bright.q should inherit 0.7 from filt_1, "
                f"got {filt_bright.params.get('q')!r}"
            )
        if filt_bright.params.get("type") != "lowpass":
            failures.append(
                f"filt_bright.type should inherit 'lowpass', "
                f"got {filt_bright.params.get('type')!r}"
            )

    # ---------------------------------------------------------------
    # 3. Cross-dialect event -> event edge recorded without warning.
    # ---------------------------------------------------------------
    cross_ok = next(
        (e for e in graph.edges
         if e.src_node == "lead_line" and e.dst_node == "env_1"),
        None,
    )
    if cross_ok is None:
        failures.append("cross-dialect edge lead_line.note_on -> env_1.trigger missing")
    elif cross_ok.warning is not None:
        failures.append(
            f"matched-shape cross-dialect edge should not warn, "
            f"got {cross_ok.warning!r}"
        )
    elif (cross_ok.shape_src, cross_ok.shape_dst) != ("event", "event"):
        failures.append(
            f"cross-dialect edge shapes wrong: "
            f"({cross_ok.shape_src}, {cross_ok.shape_dst})"
        )

    # ---------------------------------------------------------------
    # 4. Deliberate mismatch recorded with warning.
    # ---------------------------------------------------------------
    cross_bad = next(
        (e for e in graph.edges
         if e.src_node == "osc_1" and e.dst_node == "env_1"
         and e.dst_port == "trigger"),
        None,
    )
    if cross_bad is None:
        failures.append("mismatch edge osc_1.out -> env_1.trigger missing")
    elif cross_bad.warning is None:
        failures.append("signal -> event mismatch should warn but didn't")

    # ---------------------------------------------------------------
    # 5. Reachability drops orphan_lfo (and filt_bright is reachable now).
    # ---------------------------------------------------------------
    table = expand.collect_top_level_ids(stmts)
    reachable = expand.reachable_from(table, "demo_root", top_level=stmts)
    if "orphan_lfo" in reachable:
        failures.append("orphan_lfo should be unreachable but was reached")
    if "filt_bright" not in reachable:
        failures.append(
            "filt_bright should be reachable now that all_voices USEs it"
        )

    # ---------------------------------------------------------------
    # 6. Topological order: osc_1 before filt_1, filt_1 before amp_1,
    #    amp_1 before out_main, etc.
    # ---------------------------------------------------------------
    order = graph.order
    def precedes(a: str, b: str) -> bool:
        try:
            return order.index(a) < order.index(b)
        except ValueError:
            return False
    constraints = [
        ("osc_1", "filt_1"),
        ("filt_1", "amp_1"),
        ("amp_1", "out_main"),
        ("osc_2", "filt_bright"),
        ("filt_bright", "amp_2"),
        ("amp_2", "out_main"),
        ("env_1", "filt_1"),       # env's value feeds filter's cutoff_mod
        ("env_1", "filt_bright"),
    ]
    for a, b in constraints:
        if not precedes(a, b):
            failures.append(
                f"topo order broken: {a!r} should precede {b!r} "
                f"in {order}"
            )

    # ---------------------------------------------------------------
    # 7. Music dialect still works.
    # ---------------------------------------------------------------
    with open(MUSIC_SRC) as f:
        mstmts = expand.parse(f.read())
    music_events = expand.expand(mstmts)
    music_out = "\n".join(ev.as_line() for ev in music_events) + "\n"
    with open(MUSIC_REF) as f:
        music_ref = f.read()
    if music_out != music_ref:
        failures.append("music dialect regressed")

    # ---------------------------------------------------------------
    # Report.
    # ---------------------------------------------------------------
    if failures:
        print(f"FAIL: {len(failures)} check(s) failed\n", file=sys.stderr)
        for f in failures:
            print(f, file=sys.stderr)
            print(file=sys.stderr)
        return 1

    print(f"OK: all 7 checks passed")
    print(f"     patch nodes:       {len(graph.nodes)}")
    print(f"     patch edges:       {len(graph.edges)}")
    print(f"     warnings:          {len(graph.warnings)}")
    print(f"     topo order:        {' -> '.join(graph.order)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
