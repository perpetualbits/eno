#!/usr/bin/env python3
"""
tests/test_prototype_d.py — smoke test for SPINE Prototype D (cello).

Verifies:

  1. The cello_phrases graph resolves to the recorded reference output.
  2. v0.3 GRP `seed N` attribute parses and inherits to humanize MODs.
  3. Per-MOD explicit `seed N` overrides the GRP seed.
  4. transition_from= USE override is captured and resolved.
  5. Verb-form curve operators (rise/fall/hold/grow/sharper) parse.
  6. Ref-form curve operators (with_depth ref(curve)) parse.
  7. Reachability follows ref() values in DEF params and USE overrides
     (this is what brings the gestures into the reachable set).
  8. Cello dialect lifetimes classify correctly.
  9. The transition resolver lookup table returns the expected
     (resolver, runtime_state_needed) for the martélé->legato case.
 10. All previous prototypes (A, B, C) still pass.

Exits 0 on success, 1 on any failure.
"""

from __future__ import annotations

import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "src"))

import expand  # noqa: E402


CELLO = os.path.join(ROOT, "examples", "cello_phrases.spine")
CELLO_REF = os.path.join(ROOT, "examples", "cello_phrases.resolved.txt")


def main() -> int:
    failures: list[str] = []

    # ----------------------------------------------------------------
    # 1. Reference match
    # ----------------------------------------------------------------
    with open(CELLO) as f:
        stmts = expand.parse(f.read())
    res = expand.expand_cello(stmts)
    rendered = expand.render_cello_resolution(res)
    with open(CELLO_REF) as f:
        expected = f.read()
    if rendered != expected:
        failures.append(
            "cello resolution does not match recorded reference\n"
            f"--- expected ---\n{expected}\n--- got ---\n{rendered}"
        )

    # ----------------------------------------------------------------
    # 2. GRP seed inheritance: notes in scene_a have seed_tuple
    #    rooted at 1234 (the GRP seed).
    # ----------------------------------------------------------------
    arc2_notes = [n for n in res.notes
                  if n.gesture_id and n.gesture_id.startswith("vib_")]
    if not arc2_notes:
        failures.append("no answering_arc notes found (expected vib_*)")
    else:
        for n in arc2_notes:
            if n.seed_tuple is None:
                failures.append(
                    f"answering_arc note at t={n.t} missing seed_tuple"
                )
            elif n.seed_tuple[0] != 1234:
                failures.append(
                    f"answering_arc note at t={n.t} has parent_seed "
                    f"{n.seed_tuple[0]} (expected 1234)"
                )

    # ----------------------------------------------------------------
    # 3. Per-MOD explicit seed override: scene_b notes have seed 2718,
    #    inherited from the MOD declarations (NOT from the GRP, which
    #    has no seed= attribute).
    # ----------------------------------------------------------------
    figure_notes = [n for n in res.notes
                    if n.gesture_id and n.gesture_id.startswith("m_")]
    if not figure_notes:
        failures.append("no insistent_figure notes found (expected m_*)")
    else:
        for n in figure_notes:
            if n.seed_tuple is None:
                failures.append(
                    f"insistent_figure note at t={n.t} missing seed_tuple"
                )
            elif n.seed_tuple[0] != 2718:
                failures.append(
                    f"insistent_figure note at t={n.t} has parent_seed "
                    f"{n.seed_tuple[0]} (expected 2718)"
                )

    # ----------------------------------------------------------------
    # 4. transition_from= captured and resolved
    # ----------------------------------------------------------------
    trans_notes = [n for n in res.notes if n.transition_from]
    if len(trans_notes) != 1:
        failures.append(
            f"expected exactly 1 transition note, got {len(trans_notes)}"
        )
    elif trans_notes[0].transition_from != "m_loudest_h":
        failures.append(
            f"transition_from should be m_loudest_h, "
            f"got {trans_notes[0].transition_from}"
        )
    elif trans_notes[0].transition_resolver != "lift_and_settle":
        failures.append(
            f"transition resolver should be lift_and_settle, "
            f"got {trans_notes[0].transition_resolver}"
        )
    elif not trans_notes[0].transition_runtime_state:
        failures.append(
            "lift_and_settle should be flagged runtime_state_needed"
        )

    # ----------------------------------------------------------------
    # 5. & 6. Verb-form and ref-form curve operators parsed correctly
    # ----------------------------------------------------------------
    g = res.gestures.get("legato_swell")
    if g is None:
        failures.append("legato_swell gesture not resolved")
    else:
        # Should contain ('with_pressure', ('rise', 0.0, 0.3))
        found_verb = any(
            op == "with_pressure" and isinstance(arg, tuple)
            and arg[0] == "rise"
            for op, arg in g.ops
        )
        if not found_verb:
            failures.append(
                f"legato_swell missing with_pressure rise verb form; "
                f"ops={g.ops}"
            )

    g = res.gestures.get("vib_swell")
    if g is None:
        failures.append("vib_swell gesture not resolved")
    else:
        # Should contain ('with_depth', ('ref', 'swell_then_settle'))
        found_ref = any(
            op == "with_depth" and isinstance(arg, tuple)
            and arg[0] == "ref" and arg[1] == "swell_then_settle"
            for op, arg in g.ops
        )
        if not found_ref:
            failures.append(
                f"vib_swell missing with_depth ref form; ops={g.ops}"
            )

    # ----------------------------------------------------------------
    # 7. Reachability follows ref() values
    # ----------------------------------------------------------------
    table = expand.collect_top_level_ids(stmts)
    reachable = expand.reachable_from(table, "demo_root", top_level=stmts)
    # base_détaché is referenced only via note DEFs' gesture=ref(base_détaché).
    if "base_détaché" not in reachable:
        failures.append(
            "base_détaché should be reachable via gesture=ref() in note DEFs"
        )
    if "swell_then_settle" not in reachable:
        failures.append(
            "swell_then_settle should be reachable via with_depth ref()"
        )
    # base_sul_tasto is not referenced anywhere; must be dropped.
    if "base_sul_tasto" in reachable:
        failures.append("base_sul_tasto should be unreachable")

    # ----------------------------------------------------------------
    # 8. Lifetime classification
    # ----------------------------------------------------------------
    expected_lifetimes = {
        "cello.gesture.détaché": "precomputed",
        "cello.gesture.martelé": "precomputed",
        "cello.gesture.vibrato_warm": "precomputed",
        "cello.note": "event-driven",
        "cello.curve.standard": "precomputed",
    }
    for type_id, expected in expected_lifetimes.items():
        actual = expand.lifetime_of(type_id)
        if actual != expected:
            failures.append(
                f"lifetime({type_id}) should be {expected!r}, got {actual!r}"
            )

    # ----------------------------------------------------------------
    # 9. Transition table lookups
    # ----------------------------------------------------------------
    resolver, rt = expand.lookup_cello_transition(
        "cello.gesture.martelé", "cello.gesture.détaché",
    )
    if resolver != "lift_and_settle" or not rt:
        failures.append(
            f"martelé->détaché should be (lift_and_settle, True), "
            f"got ({resolver}, {rt})"
        )
    resolver, rt = expand.lookup_cello_transition(
        "cello.gesture.legato", "cello.gesture.legato",
    )
    if resolver != "continue_bow" or rt:
        failures.append(
            f"legato->legato should be (continue_bow, False), "
            f"got ({resolver}, {rt})"
        )
    # Wildcard match for any -> pizzicato
    resolver, rt = expand.lookup_cello_transition(
        "cello.gesture.vibrato_warm", "cello.gesture.pizzicato",
    )
    if resolver != "pluck_attack":
        failures.append(
            f"vibrato_warm->pizzicato should be pluck_attack, got {resolver}"
        )

    # ----------------------------------------------------------------
    # 10. Previous prototypes still pass
    # ----------------------------------------------------------------
    for label in ("a", "b", "c"):
        path = os.path.join(HERE, f"test_prototype_{label}.py")
        r = subprocess.run(
            [sys.executable, path], capture_output=True, text=True,
        )
        if r.returncode != 0:
            failures.append(
                f"Prototype {label.upper()} regressed:\n{r.stderr or r.stdout}"
            )

    # ----------------------------------------------------------------
    # Report
    # ----------------------------------------------------------------
    if failures:
        print(f"FAIL: {len(failures)} check(s) failed\n", file=sys.stderr)
        for f in failures:
            print(f, file=sys.stderr)
            print(file=sys.stderr)
        return 1

    print(f"OK: all 10 checks passed")
    print(f"     gesture variants: {len(res.gestures)}")
    print(f"     notes resolved:   {len(res.notes)}")
    print(f"     transitions:      {len(trans_notes)}")
    print(f"     warnings:         {len(res.warnings)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
