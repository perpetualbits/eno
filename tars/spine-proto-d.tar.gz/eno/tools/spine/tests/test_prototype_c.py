#!/usr/bin/env python3
"""
tests/test_prototype_c.py — smoke test for SPINE Prototype C (streaming).

Verifies:

  1. The bladerunner_sketch graph resolves to the recorded reference.
  2. Lifetime classification is correct for new types
     (oscillator=streaming, dice=event-driven, etc.).
  3. The feedback loop through allpass delays is allowed; non-cycle
     edges into delay inputs do NOT get the feedback flag.
  4. The simulator runs the patch for 5 simulated seconds without
     producing NaN, Inf, or unbounded growth (RMS bounded).
  5. The scene_out probe is non-flat (signal actually reaches the
     output through the reverb's feedback loop — this is the load-
     bearing check for feedback handling).
  6. The LFO probes evolve over time (modulation is alive).
  7. Reachability still drops orphan nodes.
  8. Prototypes A and B still pass unchanged.

Exits 0 on success, 1 on any failure.
"""

from __future__ import annotations

import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "src"))

import expand    # noqa: E402
import simulate  # noqa: E402


SKETCH = os.path.join(ROOT, "examples", "bladerunner_sketch.spine")
GRAPH_REF = os.path.join(ROOT, "examples", "bladerunner_sketch.graph.txt")


def main() -> int:
    failures: list[str] = []

    # --- 1. Graph reference -----------------------------------------
    with open(SKETCH) as f:
        stmts = expand.parse(f.read())
    graph = expand.expand_patch(stmts)
    rendered = expand.render_patch_graph(graph)
    with open(GRAPH_REF) as f:
        expected = f.read()
    if rendered != expected:
        failures.append(
            "bladerunner graph does not match reference\n"
            f"--- expected ---\n{expected}\n--- got ---\n{rendered}"
        )

    # --- 2. Lifetime classifications --------------------------------
    expected_lifetimes = {
        "patch.oscillator":    "streaming",
        "patch.lfo":           "streaming",
        "patch.noise":         "streaming",
        "patch.clock":         "streaming",
        "patch.dice":          "event-driven",
        "patch.envelope":      "event-driven",
        "patch.lowpass":       "streaming",
        "patch.highpass":      "streaming",
        "patch.delay":         "streaming",
        "patch.allpass_delay": "streaming",
        "patch.mixer":         "streaming",
        "patch.scene_out":     "sink",
        "patch.output":        "sink",
    }
    for type_id, expected in expected_lifetimes.items():
        actual = expand.lifetime_of(type_id)
        if actual != expected:
            failures.append(
                f"lifetime({type_id}) should be {expected!r}, got {actual!r}"
            )

    # --- 3. Feedback edges --------------------------------------------
    # The cycle is reverb_ap1 <-> reverb_ap2. Those two edges should be
    # the ONLY ones flagged. master_mix -> reverb_ap1 is NOT in the
    # cycle and should not be flagged.
    fb_edges = [(e.src_node, e.dst_node) for e in graph.edges if e.is_feedback]
    fb_set = set(fb_edges)
    expected_fb = {("reverb_ap1", "reverb_ap2"), ("reverb_ap2", "reverb_ap1")}
    if fb_set != expected_fb:
        failures.append(
            f"feedback edges wrong: expected {expected_fb}, got {fb_set}"
        )
    # Specifically, master_mix -> reverb_ap1 must NOT be feedback.
    for e in graph.edges:
        if e.src_node == "master_mix" and e.dst_node == "reverb_ap1":
            if e.is_feedback:
                failures.append(
                    "master_mix -> reverb_ap1 was flagged as feedback "
                    "but is not part of any cycle"
                )

    # --- 4. Simulator runs without NaN/Inf or unbounded growth -------
    probe_tuples = simulate.select_probes(graph, None)
    result = simulate.simulate(graph, duration_s=5.0, rate_hz=100.0,
                                seed=42, probes=probe_tuples)
    for name, st in result.stats.items():
        if st.nan_count > 0:
            failures.append(f"probe {name} saw {st.nan_count} NaN values")
        if st.inf_count > 0:
            failures.append(f"probe {name} saw {st.inf_count} Inf values")
        if st.rms() > 100.0:
            # Sanity bound. If the feedback diverges, RMS will be
            # astronomical. 100 is well above any plausible sane RMS
            # for signals nominally in [-1, 1].
            failures.append(
                f"probe {name} RMS={st.rms():.2f} suggests divergence"
            )

    # --- 5. scene_out is non-flat ------------------------------------
    scene_stat = result.stats.get("scene_main.in")
    if scene_stat is None:
        failures.append("scene_main.in not probed")
    elif abs(scene_stat.max_v - scene_stat.min_v) < 0.1:
        failures.append(
            f"scene_main.in is flat (min={scene_stat.min_v}, "
            f"max={scene_stat.max_v}); signal not reaching output"
        )

    # --- 6. LFOs evolve ----------------------------------------------
    for lfo_id in ("lfo_a", "lfo_b"):
        key = f"{lfo_id}.out"
        st = result.stats.get(key)
        if st is None:
            failures.append(f"{key} not probed")
            continue
        if abs(st.max_v - st.min_v) < 0.05:
            failures.append(
                f"{key} did not evolve (min={st.min_v}, max={st.max_v})"
            )

    # --- 7. Reachability drops orphan_osc ----------------------------
    table = expand.collect_top_level_ids(stmts)
    reachable = expand.reachable_from(table, "demo_root", top_level=stmts)
    if "orphan_osc" in reachable:
        failures.append("orphan_osc should be unreachable")

    # --- 8. Prototype A and B still pass -----------------------------
    # We import and run them inline rather than execv'ing.
    a_path = os.path.join(HERE, "test_prototype_a.py")
    b_path = os.path.join(HERE, "test_prototype_b.py")
    import subprocess
    for label, path in (("A", a_path), ("B", b_path)):
        r = subprocess.run(
            [sys.executable, path], capture_output=True, text=True,
        )
        if r.returncode != 0:
            failures.append(
                f"Prototype {label} regressed:\n{r.stderr or r.stdout}"
            )

    # --- Report ------------------------------------------------------
    if failures:
        print(f"FAIL: {len(failures)} check(s) failed\n", file=sys.stderr)
        for f in failures:
            print(f, file=sys.stderr)
            print(file=sys.stderr)
        return 1

    print(f"OK: all 8 checks passed")
    print(f"     graph nodes:       {len(graph.nodes)}")
    print(f"     graph edges:       {len(graph.edges)}")
    print(f"     feedback edges:    {len([e for e in graph.edges if e.is_feedback])}")
    print(f"     sim duration:     {result.duration_s:.1f} s "
          f"@ {result.rate_hz:.0f} Hz")
    print(f"     scene_main.in RMS: {result.stats['scene_main.in'].rms():.3f}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
