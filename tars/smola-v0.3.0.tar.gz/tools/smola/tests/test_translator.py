"""End-to-end tests for the v0.3 translator."""

import pytest

from smola.errors import (CollisionError, FrameError, ParseError,
                           RegAllocError, SmolaError, StructError, LexError)
from smola.translator import Translator


def translate(src: str, **kwargs) -> str:
    return Translator(filename="<test>", **kwargs).translate(src)


def test_empty_function():
    out = translate("""
func empty
end
""")
    assert "empty:" in out
    assert "ret" in out
    assert ".size empty, .-empty" in out


def test_int_decl_no_init():
    out = translate("""
func f
    int x
end
""")
    assert "x: t0" in out  # bindings table entry
    # No initialization instruction emitted — check for explicit
    # absence of 'li t0' which would only appear from `int x N` init.
    assert "li   t0," not in out


def test_int_decl_with_init():
    out = translate("""
func f
    int x 42
end
""")
    assert "li   t0, 42" in out


def test_int_decl_hex_init():
    out = translate("""
func f
    int x 0xDEAD
end
""")
    assert "li   t0, 0xDEAD" in out


def test_anonymous_temp_reserved_for_v04():
    src = """
func f
    int 10
end
"""
    with pytest.raises(ParseError, match="anonymous temporaries reserved"):
        translate(src)


def test_storage_suffixes():
    out = translate("""
func f
    int.s persistent
    int.a x
    int.a y = a3
end
""")
    # persistent -> s0
    assert "persistent: s0" in out
    # x -> a0 (first arg)
    assert "x: a0" in out
    # y -> a3 (pinned)
    assert "y: a3" in out


def test_method_implicit_self():
    out = translate("""
struct Box { side: i64, }
func Box.area
    int t
    load_field t, self, Box.side
    mul t, t, t
    zap self
    mv a0, t
end
""")
    assert "Box_area:" in out
    assert "ld   t0, 0(a0)" in out
    assert "mul t0, t0, t0" in out


def test_func_dot_without_struct_is_passthrough():
    """`func foo.helper` where 'foo' isn't a declared struct still
    emits `foo_helper:` but without implicit self binding."""
    out = translate("""
func foo.helper
    int x
end
""")
    assert "foo_helper:" in out


def test_struct_emits_set_directives():
    out = translate("""
struct Point { x: i64, y: i64, }
""")
    assert ".set Point_x_offset, 0" in out
    assert ".set Point_y_offset, 8" in out


def test_var_s_triggers_prologue():
    out = translate("""
func use_s
    int.s x
    mv x, a0
    mv a0, x
end
""")
    assert "addi sp, sp, -16" in out
    assert "sd   s0" in out


def test_call_triggers_ra_save():
    out = translate("""
func with_call
    int.s x
    mv x, a0
    call helper
    mv a0, x
end
""")
    assert "sd   ra" in out


def test_collision_in_rv_insn():
    src = """
func bad
    int counter
    addi t0, t0, 1
end
"""
    with pytest.raises(CollisionError, match="counter"):
        translate(src)


def test_collision_via_xn_alias():
    src = """
func bad
    int counter
    addi x5, x5, 1
end
"""
    with pytest.raises(CollisionError, match="counter"):
        translate(src)


def test_scope_auto_frees():
    out = translate("""
func scoped
    int.s x
    scope
        int tmp
        add tmp, x, x
        mv x, tmp
    endscope
    mv a0, x
end
""")
    assert "scope end" in out
    # tmp's register should be reusable after endscope


def test_label_recognized_in_branch():
    """Labels declared with `name:` resolve in branch operands."""
    out = translate("""
func f
    int counter
    li counter, 10
loop:
    addi counter, counter, -1
    bnez counter, loop
end
""")
    assert "loop:" in out
    assert "bnez t0, loop" in out


def test_unknown_mnemonic_in_function():
    """Typos surface at lex time, not at execution time."""
    src = """
func bad
    addii a0, a0, 1
end
"""
    with pytest.raises(LexError, match="unknown mnemonic"):
        translate(src)


def test_flt_f32_init():
    out = translate("""
func f
    flt gain 0.5
end
""")
    # 0.5 as f32 is 0x3f000000.
    assert "li   t0, 0x3f000000" in out
    assert "fmv.w.x ft0, t0" in out


def test_flt_f64_init():
    out = translate("""
func f
    f64 precise 0.5
end
""")
    # 0.5 as f64 should land in a literal pool.
    assert "Lflt_f_" in out
    assert ".dword 0x" in out
    assert "fld " in out


def test_zap_returns_register_to_pool():
    out = translate("""
func reuse
    int x
    zap x
    int y
end
""")
    # Both x and y land in t0.
    lines = [l for l in out.splitlines() if "t0" in l]
    # At least one binding line mentions t0 for x and one for y.
    assert any("x: t0" in l for l in lines)
    assert any("y: t0" in l for l in lines)


def test_endscope_without_scope():
    src = """
func bad
    endscope
end
"""
    with pytest.raises(RegAllocError, match="without matching"):
        translate(src)


def test_unclosed_scope():
    src = """
func bad
    scope
    int x
end
"""
    with pytest.raises(RegAllocError, match="unclosed scope"):
        translate(src)


def test_unclosed_function():
    src = """
func dangling
    int x
"""
    with pytest.raises(FrameError, match="never closed"):
        translate(src)


def test_provenance_suppressed():
    src = """
func q
    int.s x
    mv x, a0
    mv a0, x
end
"""
    on = translate(src, emit_provenance=True)
    off = translate(src, emit_provenance=False)
    assert "# smola: bindings" in on
    assert "# smola: bindings" not in off


def test_block_comment_before_func_transfers():
    out = translate("""
# This function does nothing.
# But it has documentation.
func empty
end
""")
    # The comments should appear in the output before the function
    # section header.
    assert "This function does nothing" in out
    assert "But it has documentation" in out
    # And the function header still appears.
    assert "empty:" in out


def test_trailing_comment_on_instruction():
    out = translate("""
func f
    int x 5
    addi x, x, 1  # bump x
end
""")
    # The comment should appear next to the substituted instruction.
    assert "addi t0, t0, 1" in out
    assert "bump x" in out


def test_raw_directive():
    out = translate("""
func f
    raw csrrw a0, mscratch, x0
end
""")
    assert "csrrw a0, mscratch, x0" in out


def test_call_pseudo_with_args_no_cycle():
    """When argument shuffle has no cycle, the SMOLA call pseudo
    emits moves correctly."""
    out = translate("""
func caller
    int x
    int y
    li x, 10
    li y, 20
    call helper, x, y
end
""")
    # x is in t0, y in t1; target is a0, a1. Moves: a0<-t0, a1<-t1.
    # No cycle.
    assert "mv   a0, t0" in out
    assert "mv   a1, t1" in out
    assert "call helper" in out


def test_call_pseudo_cycle_detected():
    src = """
func swap
    int.a x
    int.a y
    call helper, y, x
end
"""
    with pytest.raises(ParseError, match="cycle"):
        translate(src)


def test_call_pseudo_with_immediate():
    out = translate("""
func c
    call helper, 42, 7
end
""")
    assert "li   a0, 42" in out
    assert "li   a1, 7" in out
    assert "call helper" in out


def test_raw_call_works_as_passthrough():
    """Bare `call helper` without comma-separated args is a raw RV
    pseudo-instruction passthrough."""
    out = translate("""
func c
    call helper
end
""")
    assert "call helper" in out
