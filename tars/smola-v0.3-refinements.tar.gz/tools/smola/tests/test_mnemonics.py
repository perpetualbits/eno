"""Tests for the mnemonic table.

Two kinds of tests:
  - "core RVA23 mnemonics are recognized" (the table covers what it
    should).
  - "common typos and unknown words are rejected" (the table doesn't
    over-include).

A sanity-check on the total count guards against accidental large
removals from the table.
"""

from smola.mnemonics import KNOWN_MNEMONICS, TOTAL_MNEMONICS, is_known_mnemonic


def test_total_count_in_reasonable_range():
    """The table should contain ~400-700 mnemonics depending on how
    we count AMO variants. If a future edit accidentally drops half
    the table, this catches it loudly."""
    assert 350 < TOTAL_MNEMONICS < 1000, \
        f"unexpected mnemonic count: {TOTAL_MNEMONICS}"


def test_rv32i_basics():
    for m in ["addi", "add", "sub", "lui", "auipc", "jal", "jalr",
              "beq", "bne", "blt", "bge", "bltu", "bgeu",
              "lb", "lh", "lw", "sb", "sh", "sw",
              "ecall", "ebreak"]:
        assert is_known_mnemonic(m), f"missing RV32I: {m}"


def test_rv64i_additions():
    for m in ["ld", "lwu", "sd", "addiw", "addw", "sllw"]:
        assert is_known_mnemonic(m), f"missing RV64I: {m}"


def test_m_extension():
    for m in ["mul", "div", "rem", "mulw", "divuw"]:
        assert is_known_mnemonic(m), f"missing M: {m}"


def test_a_extension_word():
    for m in ["lr.w", "sc.w", "amoadd.w", "amoswap.w.aq",
              "amoadd.d.rl", "amomax.d.aqrl"]:
        assert is_known_mnemonic(m), f"missing A: {m}"


def test_f_extension():
    for m in ["fadd.s", "fmul.s", "fdiv.s", "flw", "fsw",
              "fmv.x.w", "fmv.w.x", "fcvt.s.w"]:
        assert is_known_mnemonic(m), f"missing F: {m}"


def test_d_extension():
    for m in ["fadd.d", "fmul.d", "fld", "fsd", "fcvt.d.s"]:
        assert is_known_mnemonic(m), f"missing D: {m}"


def test_c_extension():
    for m in ["c.addi", "c.li", "c.jr", "c.beqz", "c.ld"]:
        assert is_known_mnemonic(m), f"missing C: {m}"


def test_zba_zbb_zbs():
    for m in ["sh1add", "sh2add",                # Zba
              "andn", "orn", "clz", "ctz",       # Zbb
              "rev8", "rori",
              "bclr", "bext", "bset", "binv"]:   # Zbs
        assert is_known_mnemonic(m), f"missing Zb*: {m}"


def test_vector_basics():
    for m in ["vsetvli", "vle32.v", "vse32.v",
              "vadd.vv", "vfmul.vf", "vmfgt.vf",
              "vfmacc.vv", "vrgather.vv"]:
        assert is_known_mnemonic(m), f"missing RVV: {m}"


def test_pseudo_instructions():
    for m in ["li", "la", "mv", "nop", "ret", "j", "jr",
              "beqz", "bnez", "call", "tail"]:
        assert is_known_mnemonic(m), f"missing pseudo: {m}"


def test_csr_pseudo_ops():
    for m in ["csrr", "csrw", "csrrw", "csrrs", "rdcycle"]:
        assert is_known_mnemonic(m), f"missing Zicsr: {m}"


def test_typos_rejected():
    """The table should NOT accept common typos."""
    for typo in ["addii", "addd", "movi", "loadi",
                 "vaddi", "vmulvv",   # missing dot
                 "lwd", "swd",        # not real mnemonics
                 "li.s",              # not a real form
                 "subw.aq"]:          # subw isn't atomic
        assert not is_known_mnemonic(typo), \
            f"table wrongly accepts typo: {typo}"


def test_smola_keywords_not_in_table():
    """SMOLA keywords (`int`, `func`, etc.) must NOT collide with the
    mnemonic table — they are checked first in the lexer, but it's
    structural to verify they don't sneak in."""
    for kw in ["int", "ptr", "flt", "vec", "func", "end",
               "scope", "endscope", "struct", "zap", "stack", "raw",
               "load_field", "store_field", "addr_field",
               "f32", "f64"]:
        assert not is_known_mnemonic(kw), \
            f"SMOLA keyword collides with mnemonic table: {kw}"
