"""Tests for the v0.3 lexer."""

import pytest

from smola.errors import LexError
from smola.lexer import LineKind, lex_line, lex_source


def lex(text: str):
    return lex_line("<test>", 1, text)


def test_blank():
    assert lex("").kind == LineKind.BLANK
    assert lex("   ").kind == LineKind.BLANK


def test_comment_hash():
    assert lex("# foo").kind == LineKind.COMMENT


def test_comment_slash():
    assert lex("// bar").kind == LineKind.COMMENT


def test_label_plain():
    line = lex("loop:")
    assert line.kind == LineKind.LABEL
    assert line.head == "loop"


def test_label_local():
    line = lex(".Lloop:")
    assert line.kind == LineKind.LABEL
    assert line.head == ".Lloop"


def test_gas_directive():
    line = lex(".section .text.foo, \"ax\"")
    assert line.kind == LineKind.GAS_DIRECTIVE
    assert line.head == ".section"


def test_smola_func():
    line = lex("func main")
    assert line.kind == LineKind.SMOLA
    assert line.head == "func"
    assert line.tail == "main"


def test_smola_int_decl():
    line = lex("int counter 10")
    assert line.kind == LineKind.SMOLA
    assert line.head == "int"
    assert line.tail == "counter 10"


def test_smola_storage_suffix():
    line = lex("int.s persistent")
    assert line.kind == LineKind.SMOLA
    assert line.head == "int.s"


def test_smola_zap():
    line = lex("zap counter")
    assert line.kind == LineKind.SMOLA
    assert line.head == "zap"


def test_rv_instruction():
    line = lex("addi sp, sp, -16")
    assert line.kind == LineKind.RV_INSN
    assert line.head == "addi"


def test_rv_compressed():
    line = lex("c.addi a0, 1")
    assert line.kind == LineKind.RV_INSN
    assert line.head == "c.addi"


def test_rv_vector():
    line = lex("vadd.vv v1, v2, v3")
    assert line.kind == LineKind.RV_INSN
    assert line.head == "vadd.vv"


def test_unknown_mnemonic_errors():
    with pytest.raises(LexError, match="unknown mnemonic"):
        lex("addii a0, a0, 1")


def test_unknown_keyword_errors():
    with pytest.raises(LexError, match="unknown mnemonic"):
        lex("foobar baz")


def test_label_with_content_rejected():
    with pytest.raises(LexError, match="content after a label"):
        lex("loop: addi a0, a0, 1")


def test_trailing_comment_preserved():
    line = lex("addi sp, sp, -16  # prologue")
    assert line.kind == LineKind.RV_INSN
    assert line.tail == "sp, sp, -16"
    assert "prologue" in line.trailing_comment


def test_smola_call_keyword_uses_rv_path():
    """`call` is in the RV mnemonic table (as a pseudo-instruction).
    The translator decides between raw and SMOLA semantics by tail
    inspection."""
    line = lex("call helper")
    assert line.kind == LineKind.RV_INSN
    assert line.head == "call"


def test_lex_source_full_file():
    src = """
# preamble comment
func main
    int x 10
    addi x, x, 1
    zap x
end
"""
    lines = lex_source("<t>", src)
    # Build a list of (kind, head) tuples for non-blank lines.
    interesting = [(l.kind, l.head) for l in lines
                   if l.kind != LineKind.BLANK]
    assert (LineKind.COMMENT, "") in interesting
    assert (LineKind.SMOLA, "func") in interesting
    assert (LineKind.SMOLA, "int") in interesting
    assert (LineKind.RV_INSN, "addi") in interesting
    assert (LineKind.SMOLA, "zap") in interesting
    assert (LineKind.SMOLA, "end") in interesting
