"""Tests for SMOLA v0.3 data-section declarations.

Covers:
  - basic data blocks of each width (u8/i8/u16/i16/u32/i32/u64/i64/
    f32/f64/ptr)
  - continuation lines on subsequent rows
  - automatic alignment via `.balign`
  - automatic `.size` directives
  - multiple labeled blocks in sequence
  - section transitions flushing prior block sizes
  - error paths: `int` in data, `vec` in data, storage suffix in
    data, missing label, numeric literal outside data section,
    continuation with no prior directive

Width-typed code variables (i8/u8/.../u64 used inside a function)
are covered in test_translator.py — this file focuses on the data
side.
"""

import pytest

from smola.errors import LexError, ParseError, SmolaError
from smola.translator import Translator


def translate(src: str, **kwargs) -> str:
    return Translator(filename="<test>", **kwargs).translate(src)


# ---------- basic data-block emission ----------

def test_simple_f32_block():
    out = translate("""
.section .rodata
coefs:
    f32 0.5 0.75 1.0
""")
    assert ".balign 4" in out
    assert ".float 0.5" in out
    assert ".float 0.75" in out
    assert ".float 1.0" in out
    # 3 floats × 4 bytes = 12.
    assert ".size coefs, 12" in out


def test_u8_block():
    out = translate("""
.section .rodata
bytes:
    u8 0 1 2 3 4
""")
    assert ".balign 1" in out
    assert ".byte 0" in out
    assert ".byte 4" in out
    assert ".size bytes, 5" in out


def test_i16_with_negative():
    out = translate("""
.section .rodata
deltas:
    i16 -3 1 2 -1 0 1
""")
    assert ".balign 2" in out
    assert ".hword -3" in out
    assert ".hword 1" in out
    # 6 hwords × 2 bytes = 12.
    assert ".size deltas, 12" in out


def test_u64_block():
    out = translate("""
.section .rodata
qwords:
    u64 0xdeadbeef 0xfeedface
""")
    assert ".balign 8" in out
    assert ".dword 0xdeadbeef" in out
    assert ".dword 0xfeedface" in out
    assert ".size qwords, 16" in out


def test_f64_block():
    out = translate("""
.section .rodata
doubles:
    f64 0.5 1.5
""")
    assert ".balign 8" in out
    assert ".double 0.5" in out
    assert ".double 1.5" in out
    assert ".size doubles, 16" in out


def test_ptr_block_with_symbols():
    """`ptr` data with symbol references — jump table pattern.
    Symbols pass through to GAS unchanged."""
    out = translate("""
.section .rodata
table:
    ptr handler_a handler_b handler_c
""")
    assert ".balign 8" in out
    assert ".dword handler_a" in out
    assert ".dword handler_b" in out
    assert ".dword handler_c" in out
    assert ".size table, 24" in out


def test_comma_separated_values():
    """Comma separators are accepted (in addition to whitespace)."""
    out = translate("""
.section .rodata
mixed:
    i32 1, 2, 3, 4
""")
    assert ".word 1" in out
    assert ".word 4" in out
    assert ".size mixed, 16" in out


# ---------- continuation lines ----------

def test_numeric_continuation_lines():
    """Values on lines following the type keyword continue the
    declaration. This is the natural way to lay out coefficient
    blocks."""
    out = translate("""
.section .rodata
coefs:
    f32  0.5  0.75  1.0
         0.25  0.125
""")
    # All five values should appear as .float.
    for v in ["0.5", "0.75", "1.0", "0.25", "0.125"]:
        assert f".float {v}" in out
    assert ".size coefs, 20" in out  # 5 × 4


def test_continuation_with_negative_values():
    out = translate("""
.section .rodata
deltas:
    i16  -3  1  2
         -1  0  1
""")
    assert ".hword -3" in out
    assert ".hword 1" in out
    assert ".hword -1" in out
    assert ".size deltas, 12" in out  # 6 × 2


def test_continuation_with_hex_literals():
    out = translate("""
.section .rodata
codes:
    u32  0xDEAD  0xBEEF
         0xFACE  0xCAFE
""")
    for v in ["0xDEAD", "0xBEEF", "0xFACE", "0xCAFE"]:
        assert f".word {v}" in out
    assert ".size codes, 16" in out


def test_label_resets_continuation_context():
    """A new label terminates the previous directive's continuation
    context. The next numeric-literal line (if any) would error
    because there's no pending directive."""
    src = """
.section .rodata
block_a:
    i32 1 2
block_b:
    3 4
"""
    with pytest.raises(ParseError, match="no preceding data directive"):
        translate(src)


def test_directive_resets_continuation_to_new_type():
    """A new type keyword resets the pending continuation type."""
    out = translate("""
.section .rodata
mixed:
    i32 1 2
    u8 3 4
""")
    assert ".word 1" in out
    assert ".byte 3" in out
    # Size is 8 (i32 × 2) + 2 (u8 × 2) = 10.
    assert ".size mixed, 10" in out


# ---------- multiple labels in one section ----------

def test_multiple_labels_separate_sizes():
    out = translate("""
.section .rodata
a:
    i32 1
b:
    i32 2
c:
    i32 3
""")
    assert ".size a, 4" in out
    assert ".size b, 4" in out
    assert ".size c, 4" in out


def test_section_change_flushes_size():
    """Transitioning from .rodata back to .text flushes the open
    data block's size."""
    out = translate("""
.section .rodata
data:
    i32 42
.section .text
func empty
end
""")
    assert ".size data, 4" in out
    # And the size should come before the .section .text line.
    size_idx = out.find(".size data, 4")
    section_idx = out.find(".section .text")
    assert 0 < size_idx < section_idx


# ---------- error paths ----------

def test_int_in_data_rejected():
    src = """
.section .rodata
x:
    int 42
"""
    with pytest.raises(ParseError, match=r"`int` is not allowed"):
        translate(src)


def test_vec_in_data_rejected():
    src = """
.section .rodata
x:
    vec 1 2 3 4
"""
    with pytest.raises(ParseError, match=r"`vec` is not allowed"):
        translate(src)


def test_storage_suffix_in_data_rejected():
    """`i32.s` is meaningful in code (callee-saved 32-bit int) but
    nonsensical in data."""
    src = """
.section .rodata
x:
    i32.s 42
"""
    with pytest.raises(ParseError, match="storage suffix"):
        translate(src)


def test_data_without_label_rejected():
    src = """
.section .rodata
    f32 0.5
"""
    with pytest.raises(ParseError, match="require a preceding label"):
        translate(src)


def test_empty_data_directive_rejected():
    src = """
.section .rodata
x:
    f32
"""
    with pytest.raises(ParseError, match="at least one value"):
        translate(src)


def test_numeric_literal_in_code_rejected():
    """Numeric literals at the start of a line are only valid as
    data continuation. In code, they're a typo."""
    src = """
func bad
    0.5 0.6
end
"""
    with pytest.raises(ParseError, match="numeric literals"):
        translate(src)


def test_numeric_literal_in_data_without_directive_rejected():
    src = """
.section .rodata
label:
    0.5 0.6
"""
    with pytest.raises(ParseError, match="no preceding data directive"):
        translate(src)


# ---------- mixed blocks (representative integration) ----------

def test_mixed_block_with_comments_and_multiple_types():
    out = translate("""
.section .rodata

# A small mixed data block.
block:
    # i16 deltas
    i16 -3 1 2
    # f32 weights
    f32 0.5 0.75
""")
    # All the values present.
    assert ".hword -3" in out
    assert ".float 0.5" in out
    # The .balign directives appear before each type's values.
    # Total size: 3 hwords (6) + 2 floats (8) = 14, but f32 alignment
    # may insert padding. The natural-alignment rule rounds the
    # f32 start to 4-byte boundary; the i16 block ended at 6 bytes,
    # so 2 bytes of padding are needed.
    #
    # However, SMOLA emits `.balign 4` as a GAS directive; GAS does
    # the padding. SMOLA itself doesn't track byte position to
    # account for the padding in `.size`. This is a known
    # limitation: the emitted `.size` will be 14 even though GAS
    # may insert 2 padding bytes, putting the true size at 16.
    #
    # For now we just verify the directives are emitted; future
    # work could track padding.
    assert ".size block, 14" in out


# ---------- width-typed code variables (cross-reference) ----------

def test_width_typed_int_in_code_bindings_table():
    """Code-section variable declarations with width-typed integer
    keywords appear in the bindings table with the declared width."""
    out = translate("""
func f
    u8 byte_counter
    u16 idx
    i32 counter
end
""")
    assert "byte_counter: t0 (u8, t)" in out
    assert "idx: t1 (u16, t)" in out
    assert "counter: t2 (i32, t)" in out


def test_width_typed_int_with_init():
    out = translate("""
func f
    u32 phase 0x80000000
end
""")
    assert "phase: t0 (u32, t)" in out
    assert "li   t0, 0x80000000" in out
