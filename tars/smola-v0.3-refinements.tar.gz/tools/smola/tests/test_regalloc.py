"""Tests for the v0.3 register allocator.

Largely a port of the v0.2 tests since the allocator core is
unchanged. The public method `free` was renamed to `zap` for
consistency with the v0.3 keyword.
"""

import pytest

from smola.errors import RegAllocError, SourceLoc
from smola.regalloc import (Allocator, Storage, VarType,
                             is_register_name, normalize_reg)


def loc(line=1):
    return SourceLoc(filename="<test>", line_no=line, line_text="(test)")


def test_int_T_basic():
    a = Allocator()
    assert a.alloc("x", VarType.INT, Storage.T, loc()) == "t0"
    assert a.alloc("y", VarType.INT, Storage.T, loc()) == "t1"


def test_ptr_shares_int_pool():
    a = Allocator()
    a.alloc("p", VarType.PTR, Storage.T, loc())
    assert a.alloc("x", VarType.INT, Storage.T, loc()) == "t1"


def test_flt_separate_pool():
    a = Allocator()
    a.alloc("x", VarType.INT, Storage.T, loc())
    assert a.alloc("g", VarType.FLT, Storage.T, loc()) == "ft0"


def test_vec_skips_v0():
    a = Allocator()
    assert a.alloc("v", VarType.VEC, Storage.T, loc()) == "v1"


def test_vec_s_rejected():
    a = Allocator()
    with pytest.raises(RegAllocError, match="callee-saved"):
        a.alloc("v", VarType.VEC, Storage.S, loc())


def test_int_S_records_for_save():
    a = Allocator()
    a.alloc("p", VarType.INT, Storage.S, loc())
    a.alloc("q", VarType.INT, Storage.S, loc())
    assert a.saved_int_S == {"s0", "s1"}


def test_explicit_pinning_argument():
    a = Allocator()
    assert a.alloc("self", VarType.PTR, Storage.A,
                   explicit_reg="a0", loc=loc()) == "a0"
    assert a.alloc("dx", VarType.INT, Storage.A,
                   explicit_reg="a3", loc=loc()) == "a3"
    assert a.alloc("y", VarType.INT, Storage.A, loc=loc()) == "a1"


def test_explicit_pinning_collision():
    a = Allocator()
    a.alloc("dx", VarType.INT, Storage.A, explicit_reg="a0", loc=loc())
    with pytest.raises(RegAllocError, match="already bound"):
        a.alloc("self", VarType.INT, Storage.A, explicit_reg="a0", loc=loc())


def test_register_name_as_variable_rejected():
    a = Allocator()
    with pytest.raises(RegAllocError, match="cannot use register name"):
        a.alloc("t0", VarType.INT, Storage.T, loc())


def test_reg_holder_through_xn_alias():
    a = Allocator()
    a.alloc("counter", VarType.INT, Storage.T, loc())   # t0 = x5
    holder = a.reg_holder("x5")
    assert holder is not None
    assert holder.name == "counter"


def test_scope_push_pop():
    a = Allocator()
    a.alloc("outer", VarType.INT, Storage.T, loc())   # t0
    a.push_scope()
    a.alloc("inner", VarType.INT, Storage.T, loc())   # t1
    freed = a.pop_scope(loc())
    assert "inner" in freed
    assert "outer" in a.bindings
    # t1 returned to pool.
    assert a.alloc("new", VarType.INT, Storage.T, loc()) == "t1"


def test_pop_scope_without_match():
    a = Allocator()
    with pytest.raises(RegAllocError, match="without matching"):
        a.pop_scope(loc())


def test_zap_t_returns_to_pool():
    a = Allocator()
    a.alloc("x", VarType.INT, Storage.T, loc())   # t0
    a.zap("x", loc())
    assert a.alloc("y", VarType.INT, Storage.T, loc()) == "t0"


def test_zap_s_does_not_return():
    a = Allocator()
    a.alloc("p", VarType.INT, Storage.S, loc())   # s0
    a.zap("p", loc())
    assert a.alloc("q", VarType.INT, Storage.S, loc()) == "s1"


def test_zap_unknown_name():
    a = Allocator()
    with pytest.raises(RegAllocError, match="unknown name"):
        a.zap("ghost", loc())


def test_zap_double_diagnostic():
    a = Allocator()
    a.alloc("x", VarType.INT, Storage.T, loc())
    a.zap("x", loc(2))
    with pytest.raises(RegAllocError, match="already zapped"):
        a.zap("x", loc(3))


def test_history_records_all_bindings():
    """The `history` list (used for the auto-bindings-table) records
    every binding ever created in the function, even after zap."""
    a = Allocator()
    a.alloc("x", VarType.INT, Storage.T, loc())
    a.alloc("y", VarType.INT, Storage.S, loc())
    a.zap("x", loc())
    assert len(a.history) == 2
    assert {b.name for b in a.history} == {"x", "y"}


def test_normalize_reg():
    assert normalize_reg("x10") == "a0"
    assert normalize_reg("f8") == "fs0"
    assert normalize_reg("fp") == "s0"
    assert normalize_reg("notreg") is None


def test_is_register_name():
    assert is_register_name("t0")
    assert is_register_name("v15")
    assert not is_register_name("counter")
