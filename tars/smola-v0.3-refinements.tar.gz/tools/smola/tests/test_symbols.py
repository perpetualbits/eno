"""Tests for the v0.3 symbol table."""

import pytest

from smola.errors import StructError
from smola.symbols import SymbolTable, define_struct


def test_simple_struct():
    s = define_struct("Point", [("x", "i64"), ("y", "i64")])
    assert s.size == 16
    assert s.align == 8


def test_natural_alignment():
    s = define_struct("Mixed", [
        ("a", "i8"),
        ("b", "i64"),
        ("c", "i16"),
        ("d", "i32"),
    ])
    assert s.field("a").offset == 0
    assert s.field("b").offset == 8
    assert s.field("c").offset == 16
    assert s.field("d").offset == 20
    assert s.size == 24


def test_f32_f64_fields():
    s = define_struct("F", [("a", "f32"), ("b", "f64")])
    assert s.field("a").load_mnemonic == "flw"
    assert s.field("b").load_mnemonic == "fld"


def test_unknown_type():
    with pytest.raises(StructError, match="unknown field type"):
        define_struct("X", [("x", "blob")])


def test_duplicate_field():
    with pytest.raises(StructError, match="duplicate field"):
        define_struct("X", [("x", "i64"), ("x", "i32")])


def test_resolve_field():
    st = SymbolTable()
    st.add_struct(define_struct("Point", [("x", "i64"), ("y", "i64")]))
    s, f = st.resolve_field("Point.x")
    assert f.name == "x"


def test_has_struct():
    st = SymbolTable()
    assert not st.has_struct("Point")
    st.add_struct(define_struct("Point", [("x", "i64")]))
    assert st.has_struct("Point")
