# tools/smolr

**S**mall **M**onolithic **O**ptimising **L**inker for **R**ISC-V Linux.

A planned executable packer for Linux/RISC-V binaries, analogous to:
- **Crinkler** (Windows / x86 / x86-64) — the gold standard for 4k/64k intros
- **smol** (Linux / x86, x86-64) — the closest equivalent on Linux

## What it would do

- Combine custom ELF layout with deep code+data compression
- Use a context-mixing or arithmetic-coding model (Crinkler-style)
- Provide a minimal RISC-V Linux loader stub that decompresses at startup
- Target sub-64k binaries for the K1/K3 boards

This is **Segher's domain** — he's a GCC maintainer and knows ELF, linkers,
and RISC-V codegen at a depth nobody else on the crew approaches. The
project will start in earnest once we have a first production approaching
the size limit.

Currently empty placeholder.
