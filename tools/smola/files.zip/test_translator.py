"""End-to-end translator tests.

These exercise the full pipeline: lex -> parse -> emit, and assert
properties of the generated assembly text.
"""

import pytest

from smola.errors import SmolaError, RegAllocError, FrameError, ParseError
from smola.translator import Translator


def translate(src: str, **kwargs) -> str:
    t = Translator(filename="<test>", **kwargs)
    return t.translate(src)


def find_insn(output: str, mnemonic: str) -> list[str]:
    """Return all output lines whose first non-whitespace token is mnemonic."""
    matches = []
    for line in output.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        head = stripped.split()[0]
        if head == mnemonic:
            matches.append(stripped)
    return matches


def test_empty_leaf_function():
    src = """
.smola.func empty
.smola.endfunc
"""
    out = translate(src)
    # Leaf with no body: just label, ret, .size.
    assert "empty:" in out
    assert "ret" in out
    assert ".size empty, .-empty" in out
    # No prologue.
    assert "addi sp, sp" not in out


def test_leaf_with_t_only_no_frame():
    src = """
.smola.func add_two
    VAR.A x
    VAR.A y
    VAR.T sum
    ADD sum, x, y
    MV a0, sum
.smola.endfunc
"""
    out = translate(src)
    assert "add  t0, a0, a1" in out
    assert "mv   a0, t0" in out
    # No callee-saved touched, no calls: should be leaf.
    assert "addi sp, sp," not in out


def test_s_register_triggers_prologue():
    src = """
.smola.func use_saved
    VAR.S x
    MV x, a0
    MV a0, x
.smola.endfunc
"""
    out = translate(src)
    # One s-register saved: 8 bytes for it, padded to 16.
    assert "addi sp, sp, -16" in out
    assert "sd   s0, 0(sp)" in out
    assert "ld   s0, 0(sp)" in out
    assert "addi sp, sp, 16" in out


def test_call_triggers_ra_save():
    src = """
.smola.func with_call
    VAR.A x
    call helper
    MV a0, x
.smola.endfunc
"""
    out = translate(src)
    assert "addi sp, sp, -16" in out
    # ra is saved (calls_other detected).
    assert "sd   ra" in out
    assert "ld   ra" in out


def test_struct_emits_set_directives():
    src = """
.smola.struct Point {
    x: i64,
    y: i64,
}
"""
    out = translate(src)
    assert ".set Point_x_offset, 0" in out
    assert ".set Point_y_offset, 8" in out
    assert ".set Point_size, 16" in out
    assert ".set Point_align, 8" in out


def test_method_implicit_self_binding():
    src = """
.smola.struct Box { side: i64, }
.smola.method Box.area
    VAR.T tmp
    LOAD_FIELD tmp, self, Box.side
    MUL a0, tmp, tmp
.smola.endmethod
"""
    out = translate(src)
    # Generated symbol name is Struct_method.
    assert "Box_area:" in out
    # 'self' resolved to a0.
    assert "ld   t0, 0(a0)" in out
    assert "mul  a0, t0, t0" in out


def test_load_field_picks_correct_mnemonic():
    src = """
.smola.struct R {
    flag: u8,
    count: u16,
    big: i64,
}
.smola.func read_all
    VAR.A r
    VAR.T t
    LOAD_FIELD t, r, R.flag
    LOAD_FIELD t, r, R.count
    LOAD_FIELD t, r, R.big
.smola.endfunc
"""
    out = translate(src)
    # u8 -> lbu, u16 -> lhu, i64 -> ld
    assert "lbu  t0, 0(a0)" in out
    assert "lhu  t0, 2(a0)" in out  # padded for 2-byte align
    assert "ld   t0, 8(a0)" in out


def test_la_field_emits_addi():
    src = """
.smola.struct R { a: i64, b: i64, }
.smola.func get_b_ptr
    VAR.A r
    VAR.T p
    LA_FIELD p, r, R.b
    MV a0, p
.smola.endfunc
"""
    out = translate(src)
    assert "addi t0, a0, 8" in out


def test_call_cycle_detected():
    src = """
.smola.func swap_then_call
    VAR.A x
    VAR.A y
    CALL helper, y, x
.smola.endfunc
"""
    with pytest.raises(ParseError, match="cycle"):
        translate(src)


def test_call_with_immediate():
    src = """
.smola.func call_const
    CALL helper, 42, 7
.smola.endfunc
"""
    out = translate(src)
    assert "li   a0, 42" in out
    assert "li   a1, 7" in out
    assert "call helper" in out


def test_call_with_struct_method_name():
    src = """
.smola.struct Box { side: i64, }
.smola.func area_caller
    VAR.A b
    CALL Box.area, b
.smola.endfunc
"""
    out = translate(src)
    assert "call Box_area" in out


def test_passthrough_line():
    src = """
.smola.func raw
    VAR.A x
    ! ecall
    MV a0, x
.smola.endfunc
"""
    out = translate(src)
    assert "ecall" in out


def test_label_inside_function():
    src = """
.smola.func loops
    VAR.A n
.Lloop:
    BEQZ n, .Ldone
    ADDI n, n, -1
    J .Lloop
.Ldone:
    MV a0, n
.smola.endfunc
"""
    out = translate(src)
    # Labels at column 0.
    assert "\n.Lloop:\n" in out or out.startswith(".Lloop:")
    assert "beqz a0, .Ldone" in out
    assert "j    .Lloop" in out


def test_unknown_var_use():
    src = """
.smola.func bad
    ADD x, y, z
.smola.endfunc
"""
    with pytest.raises(RegAllocError, match="unknown name"):
        translate(src)


def test_unclosed_function():
    src = """
.smola.func dangling
    VAR.A x
"""
    with pytest.raises(FrameError, match="never closed"):
        translate(src)


def test_endfunc_without_open():
    src = """
.smola.endfunc
"""
    with pytest.raises(FrameError, match="without matching"):
        translate(src)


def test_provenance_can_be_suppressed():
    src = """
.smola.func quiet
    VAR.A x
    MV a0, x
.smola.endfunc
"""
    out_with = translate(src, emit_provenance=True)
    out_without = translate(src, emit_provenance=False)
    assert "# smola: bind" in out_with
    assert "# smola: bind" not in out_without


def test_free_returns_register():
    src = """
.smola.func reuse
    VAR.T x
    MV x, a0
    FREE x
    VAR.T y
    MV a0, y
.smola.endfunc
"""
    out = translate(src)
    # Both x and y should land in t0 due to reuse.
    assert "mv   t0, a0" in out
    assert "mv   a0, t0" in out


def test_double_struct_decl():
    from smola.errors import StructError
    src = """
.smola.struct P { x: i64, }
.smola.struct P { y: i64, }
"""
    with pytest.raises(StructError, match="already declared"):
        translate(src)


def test_t_pool_exhaustion_message():
    src = """
.smola.func full
""" + "\n".join(f"    VAR.T v{i}" for i in range(8)) + """
.smola.endfunc
"""
    with pytest.raises(RegAllocError, match="no caller-saved"):
        translate(src)
