"""Unit tests for the struct/symbol table."""

import pytest

from smola.errors import StructError
from smola.symbols import SymbolTable, define_struct


def test_simple_struct():
    s = define_struct("Point", [("x", "i64"), ("y", "i64")])
    assert s.size == 16
    assert s.align == 8
    assert s.field("x").offset == 0
    assert s.field("y").offset == 8


def test_packed_aligned():
    """Field layout respects natural alignment."""
    s = define_struct("Mixed", [
        ("a", "i8"),
        ("b", "i64"),    # needs 8-byte alignment
        ("c", "i16"),
        ("d", "i32"),    # needs 4-byte alignment
    ])
    assert s.field("a").offset == 0
    assert s.field("b").offset == 8   # padded from offset 1 to 8
    assert s.field("c").offset == 16
    assert s.field("d").offset == 20  # padded from 18 to 20 for 4-byte align
    assert s.size == 24                # rounded up to 8-byte struct align


def test_unknown_type():
    with pytest.raises(StructError, match="unknown field type"):
        define_struct("Bad", [("x", "f128")])


def test_duplicate_field():
    with pytest.raises(StructError, match="duplicate field"):
        define_struct("Bad", [("x", "i64"), ("x", "i32")])


def test_resolve_field():
    st = SymbolTable()
    st.add_struct(define_struct("Point", [("x", "i64"), ("y", "i64")]))
    s, f = st.resolve_field("Point.x")
    assert s.name == "Point"
    assert f.name == "x"
    assert f.load_mnemonic == "ld"


def test_resolve_field_unknown_struct():
    st = SymbolTable()
    with pytest.raises(StructError, match="unknown struct"):
        st.resolve_field("Ghost.x")


def test_resolve_field_unknown_field():
    st = SymbolTable()
    st.add_struct(define_struct("Point", [("x", "i64"), ("y", "i64")]))
    with pytest.raises(StructError, match="no field"):
        st.resolve_field("Point.z")


def test_load_store_mnemonics():
    s = define_struct("All", [
        ("a", "i8"), ("b", "u8"),
        ("c", "i16"), ("d", "u16"),
        ("e", "i32"), ("f", "u32"),
        ("g", "i64"), ("h", "ptr"),
    ])
    assert s.field("a").load_mnemonic == "lb"
    assert s.field("b").load_mnemonic == "lbu"
    assert s.field("c").load_mnemonic == "lh"
    assert s.field("d").load_mnemonic == "lhu"
    assert s.field("e").load_mnemonic == "lw"
    assert s.field("f").load_mnemonic == "lwu"
    assert s.field("g").load_mnemonic == "ld"
    assert s.field("h").load_mnemonic == "ld"
    # Stores
    assert s.field("a").store_mnemonic == "sb"
    assert s.field("c").store_mnemonic == "sh"
    assert s.field("e").store_mnemonic == "sw"
    assert s.field("g").store_mnemonic == "sd"
