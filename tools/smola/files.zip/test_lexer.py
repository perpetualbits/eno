"""Unit tests for the lexer."""

import pytest

from smola.errors import LexError
from smola.lexer import LineKind, lex_line, lex_source


def lex(text: str):
    return lex_line("<test>", 1, text)


def test_blank():
    assert lex("").kind == LineKind.BLANK
    assert lex("   ").kind == LineKind.BLANK


def test_comment_hash():
    line = lex("# a comment")
    assert line.kind == LineKind.COMMENT
    assert "a comment" in line.tail


def test_comment_slash():
    line = lex("// also a comment")
    assert line.kind == LineKind.COMMENT


def test_passthrough():
    line = lex("! csrr a0, mhartid")
    assert line.kind == LineKind.PASSTHROUGH
    assert line.tail == "csrr a0, mhartid"


def test_smola_directive():
    line = lex(".smola.func foo")
    assert line.kind == LineKind.SMOLA_DIRECTIVE
    assert line.head == "func"
    assert line.tail == "foo"


def test_gas_directive():
    line = lex(".section .text.foo, \"ax\", @progbits")
    assert line.kind == LineKind.GAS_DIRECTIVE
    assert line.head == ".section"


def test_label_simple():
    line = lex("foo:")
    assert line.kind == LineKind.LABEL
    assert line.head == "foo"


def test_label_local():
    """Local labels like .Lloop: are LABEL, not GAS_DIRECTIVE."""
    line = lex(".Lloop:")
    assert line.kind == LineKind.LABEL
    assert line.head == ".Lloop"


def test_label_with_content_rejected():
    with pytest.raises(LexError, match="content after a label"):
        lex("foo: addi sp, sp, -16")


def test_smola_insn():
    line = lex("ADD result, a, b")
    assert line.kind == LineKind.INSN_SMOLA
    assert line.head == "ADD"
    assert line.tail == "result, a, b"


def test_raw_insn():
    line = lex("addi sp, sp, -16")
    assert line.kind == LineKind.INSN_RAW
    assert line.head == "addi"


def test_smola_var_directive():
    line = lex("VAR.T counter")
    assert line.kind == LineKind.INSN_SMOLA
    assert line.head == "VAR.T"


def test_trailing_comment_on_insn():
    line = lex("ADD a, b, c  # sum")
    assert line.kind == LineKind.INSN_SMOLA
    assert line.tail == "a, b, c"
    assert "sum" in line.trailing_comment


def test_lex_source_counts():
    src = "# comment\n.smola.func foo\nVAR.T x\nADD a, b, c\n.smola.endfunc\n"
    lines = lex_source("<test>", src)
    assert len(lines) == 5
    assert lines[0].kind == LineKind.COMMENT
    assert lines[1].kind == LineKind.SMOLA_DIRECTIVE
    assert lines[2].kind == LineKind.INSN_SMOLA
    assert lines[3].kind == LineKind.INSN_SMOLA
    assert lines[4].kind == LineKind.SMOLA_DIRECTIVE
