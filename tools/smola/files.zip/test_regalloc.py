"""Unit tests for the register allocator."""

import pytest

from smola.errors import RegAllocError, SourceLoc
from smola.regalloc import Allocator, RegKind, normalize_reg


def loc(line=1):
    return SourceLoc(filename="<test>", line_no=line, line_text="(test)")


def test_alloc_T_basic():
    a = Allocator()
    assert a.alloc_T("x", loc()) == "t0"
    assert a.alloc_T("y", loc()) == "t1"
    assert a.bindings["x"].reg == "t0"
    assert a.bindings["x"].kind == RegKind.T


def test_alloc_T_exhausts():
    a = Allocator()
    for i in range(7):
        a.alloc_T(f"v{i}", loc())
    with pytest.raises(RegAllocError, match="no caller-saved"):
        a.alloc_T("overflow", loc())


def test_alloc_S_records_for_save():
    a = Allocator()
    a.alloc_S("p", loc())
    a.alloc_S("q", loc())
    assert a.saved_S == {"s0", "s1"}


def test_alloc_A_implicit_order():
    a = Allocator()
    assert a.alloc_A("self", loc=loc()) == "a0"
    assert a.alloc_A("x", loc=loc()) == "a1"


def test_alloc_A_explicit():
    a = Allocator()
    assert a.alloc_A("dx", explicit_reg="a3", loc=loc()) == "a3"
    # a0..a2 should still be available.
    assert a.alloc_A("self", loc=loc()) == "a0"


def test_alloc_A_explicit_conflict():
    a = Allocator()
    a.alloc_A("dx", explicit_reg="a0", loc=loc())
    with pytest.raises(RegAllocError, match="already bound"):
        a.alloc_A("self", explicit_reg="a0", loc=loc())


def test_double_bind():
    a = Allocator()
    a.alloc_T("x", loc())
    with pytest.raises(RegAllocError, match="already bound"):
        a.alloc_T("x", loc())


def test_free_returns_T_to_pool():
    a = Allocator()
    a.alloc_T("x", loc())
    a.free("x", loc())
    # Next T allocation should reuse t0.
    assert a.alloc_T("y", loc()) == "t0"


def test_free_S_does_not_return_to_pool():
    """v1 design: S registers stay reserved after FREE."""
    a = Allocator()
    a.alloc_S("p", loc())
    a.free("p", loc())
    # The reg is still "in saved_S" so prologue still saves it,
    # but the free pool does not get s0 back.
    next_s = a.alloc_S("q", loc())
    assert next_s == "s1"


def test_use_after_free():
    a = Allocator()
    a.alloc_T("x", loc())
    a.free("x", loc(2))
    with pytest.raises(RegAllocError, match="freed at"):
        a.resolve("x", loc(3))


def test_resolve_raw_reg_passthrough():
    a = Allocator()
    assert a.resolve("t3", loc()) == "t3"
    assert a.resolve("x10", loc()) == "a0"


def test_resolve_unknown():
    a = Allocator()
    with pytest.raises(RegAllocError, match="unknown name"):
        a.resolve("ghost", loc())


def test_alias_shares_register():
    a = Allocator()
    a.alloc_T("x", loc())
    reg = a.alias("y", "x", loc())
    assert reg == a.resolve("x", loc())
    # FREE of one name doesn't return the reg to the pool while the
    # other alias still holds it.
    a.free("x", loc())
    assert a.resolve("y", loc()) == reg
    # Now free the alias too; reg returns.
    a.free("y", loc())
    assert a.alloc_T("z", loc()) == "t0"


def test_normalize_reg():
    assert normalize_reg("x0") == "zero"
    assert normalize_reg("x10") == "a0"
    assert normalize_reg("t0") == "t0"
    assert normalize_reg("sp") == "sp"
    assert normalize_reg("notareg") is None
